function H = W2H(W)
% make sure H and W are in Fourier domain
H=W-1;
end