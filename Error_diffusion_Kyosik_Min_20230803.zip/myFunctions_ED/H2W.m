function W=H2W(H)
% make sure H and W are in Fourier domain
W = H+1;
end